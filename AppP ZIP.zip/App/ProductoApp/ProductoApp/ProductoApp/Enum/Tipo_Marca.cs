﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductoApp.Marca
{
    public enum Tipo_Marca
    {
        Samsung,
        Motorola,
        LG,
        Blue,
        Nokia
    }
}
